# Hodnotici tabulka - uloha 1

Jmeno a prijmeni:  
Cviceni:  
Projekt: PGRF2 uloha 1

| Pozadavek | Splneno | Reseni / ovladani |
| --- | ---: | --- |
| Program zobrazi jednoduchou grafickou scenu alespon ze tri teles | 1 | Scena obsahuje krychli, kouli, valec, kuzel, ctyrsten a svetlo. |
| Koule definovana stredem a polomerem | 1 | `GeometryFactory.sphere`, ve scene jako `2 Koule`. |
| Krychle, ctyrsten | 1 | `1 Krychle`, `5 Ctyrsten`. |
| Valec, kuzel nebo podobne teleso | 1 | `3 Valec`, `4 Kuzel`. |
| Topologie, geometrie, rozsireny vertex | 1 | `Vertex` uklada pozici, barvu, UV a normalu. |
| Moznost ukladani hran i ploch | 1 | `Mesh.faces` a `Mesh.edges`. |
| Translaci teles jednotlivě | 1 | `T` + sipky, `PageUp/PageDown` pro Z. |
| Rotace kolem jednotlivych os | 1 | `R` + sipky, `PageUp/PageDown` pro Z. |
| Zoom / scale aktivniho telesa | 1 | `Y` + sipky. |
| Vyber aktivniho telesa | 1 | Klik do sceny, combobox, klavesy `1` az `6`. |
| Kamera - rozhlizeni mysi | 1 | Tazeni mysi meni azimut a zenit. |
| Kamera - pohyb WSAD | 1 | `WASD`, navic `Q/E` nahoru/dolu. |
| Pravouhla projekce | 1 | Klavesa `P`, UI tlacitko. |
| Perspektivni projekce | 1 | Klavesa `P`, UI tlacitko. |
| Rasterizace hran | 1 | Dratovy rezim `M`, hrany jdou pres Z-buffer. |
| Rasterizace ploch | 1 | Vyplnene plochy v rezimu `M`. |
| Viditelnost hran pomoci Z-bufferu | 1 | `SoftwareRasterizer.drawLine`. |
| Viditelnost ploch pomoci Z-bufferu | 1 | `SoftwareRasterizer.rasterTriangle`. |
| Orezani zobrazovacim objemem | 1 | Trivialni odmitnuti mimo obraz, near/far kontrola. |
| Orezani Z | 1 | Trojuhelniky i usecky jsou orezany na near plane. |
| Orezani XY | 1 | Rasterizace pouziva orezany bounding box do rozmeru okna. |
| Prepinani dratoveho modelu a ploch | 1 | Klavesa `M`, UI tlacitko. |
| Jednobarevne plochy / interpolace barvy | 1 | Barvy jsou ulozene ve vertexech a interpolovane. |
| Mapovani textury | 1 | Kazde hlavni teleso ma jinou proceduralni texturu. |
| Zapnuti/vypnuti textury na aktivnim telese | 1 | Klavesa `U`, UI tlacitko. |
| RGB osy a sipka | 1 | Osy jsou kreslene jako hrana a trojuhelnikova sipka. |
| Ambientni slozka osvetleni | 1 | `shade`: ambientni prispevek. |
| Difuzni slozka osvetleni | 1 | `shade`: Lambert difuzni slozka. |
| Znazorneni polohy zdroje svetla | 1 | `6 Svetlo` je mala koule. |
| Barva koule odpovida difuzni barve svetla | 1 | `C` cykluje barvu a koule ji zobrazuje. |
| Svetlo lze zvolit jako aktivni teleso a posunout | 1 | Vyber `6 Svetlo`, `T` + sipky. |
| Odevzdani aplikace v pozadovanem formatu | 1 | Slozka `uloha1`, zdrojaky, JAR a spousteci skripty, zabaleno do `uloha1.zip`. |
| GitLab privatni repozitar + odkaz | 0 | |
| Pravidelne komentovane commity | 0 | |
| Bonus: animace zdroje svetla | 1 | Mezernik zapne/vypne obeh svetla. |
| Bonus: jina topologie nez seznam trojuhelniku | 1 | Krychle/valec pouzivaji quady/fany a pak triangulaci. |
| Bonus: funkcionalni interface pro shader/texturu | 1 | `@FunctionalInterface ProceduralTexture`. |
| Bonus: perspektivne korektni interpolace | 1 | UV a atributy se interpoluji pres `1/z`. |
| Bonus: spekularni slozka | 1 | `shade`: Phong spekularni prispevek. |
| Bonus: bikubicka plocha | 0 | |
| Vlastni rozsireni UI | 1 | Infopanel, combobox, tlacitka a prepinace. |
