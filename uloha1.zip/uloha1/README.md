# PGRF2 uloha 1

Samostatna odevzdavaci verze programu pro zadani ulohy 1.

## Spusteni

PowerShell:

```powershell
.\build.ps1
.\run.ps1
```

CMD:

```bat
build.bat
run.bat
```

Rucne:

```powershell
javac --release 17 -encoding UTF-8 -d out src\*.java
jar --create --file dist\uloha1.jar --main-class Main -C out .
java -jar dist\uloha1.jar
```

## Ovladani

| Funkce | Ovladani |
| --- | --- |
| Vyber telesa | Klik do sceny, combobox, klavesy `1` az `6` |
| Posun aktivniho telesa | `T` a sipky, `PageUp/PageDown` pro osu Z |
| Rotace aktivniho telesa | `R` a sipky, `PageUp/PageDown` pro osu Z |
| Scale aktivniho telesa | `Y` a sipky |
| Kamera | Mys, `WASD`, `Q/E`, `Shift` pro rychlejsi pohyb |
| Projekce | `P` perspektivni / pravouhla |
| Plochy / drat | `M` |
| Textura aktivniho telesa | `U` |
| Barva svetla | `C` |
| Animace svetla | Mezernik |

## Co zustalo v odevzdavce

- koule, krychle, ctyrsten, valec, kuzel a svetlo jako vybratelne teleso,
- reprezentace vertexu: pozice, barva, UV, normala,
- samostatne ulozene plochy i hrany v `Mesh`,
- rasterizace ploch i hran pres vlastni Z-buffer,
- orezani na near plane a XY orezani v rasterizaci,
- perspektivni a pravouhla projekce,
- interpolace barvy, proceduralni textury a perspektivne korektni UV,
- ambientni, difuzni a spekularni osvetleni,
- RGB osy s hranou a trojuhelnikovou sipkou,
- jednoduche UI pouze pro funkce, ktere jsou v zadani.

Soubor `docs/hodnotici-tabulka-vyplnena.md` obsahuje vyplneni pozadavku a ovladani.
